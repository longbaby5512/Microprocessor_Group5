#include "WiFiInput.h"

void WiFiInput::begin()
{
    server.begin();
}

void WiFiInput::handleNotFound()
{
    String message = "File Not Found\n\n";
    message += "URI: ";
    message += server.uri();
    message += "\nMethod: ";
    message += (server.method() == HTTP_GET) ? "GET" : "POST";
    message += "\nArguments: ";
    message += server.args();
    message += "\n";
    for (uint8_t i = 0; i < server.args(); i++)
        message += " " + server.argName(i) + ": " + server.arg(i) + "\n";
    server.send(404, "text/plain", message);
}

/**
 * @brief Function for writing WiFi creds to EEPROM
 * @param ssid ssid of WiFi to write to EEPROM
 * @param pass password of WiFi to write to EEPROM
 * @return rue if save successful, else false 
 */
bool WiFiInput::writeToMemory(String ssid, String pass)
{
    char buff1[30];
    char buff2[30];
    ssid.toCharArray(buff1, 30);
    pass.toCharArray(buff2, 30);
    EEPROM.writeString(100, buff1);
    EEPROM.writeString(200, buff2);
    delayMicroseconds((int)100e3);
    String s = EEPROM.readString(100);
    String p = EEPROM.readString(200);

    if (ssid == s && pass == p)
        return true;
    return false;
}

/**
 * @brief Function for handling form
 */
void WiFiInput::handleSubmit()
{
    String response_success = "<h1>Success</h1>";
    response_success += "<h2>Device will restart in 3 seconds</h2>";

    String response_error = "<h1>Error</h1>";
    response_error += "<h2><a href='/'>Go back</a>to try again";

    if (writeToMemory(String(server.arg("ssid")), String(server.arg("password"))))
    {
        server.send(200, "text/html", response_success);
        EEPROM.commit();
        delayMicroseconds((uint32_t)3000e3);
        ESP.restart();
    }
    else
        server.send(200, "text/html", response_error);
}

/**
 * @brief Function for home page
 * 
 */
void WiFiInput::handleRoot()
{
    if (server.hasArg("ssid") && server.hasArg("password"))
        handleSubmit();
    else
        server.send(200, "text/html", INDEX_HTML);
}

/**
 * @brief Function for loading form
 * 
 * @return true if have WiFi creds in EEPROM, else false 
 */
bool WiFiInput::loadWiFiCredsForm()
{
    String s = EEPROM.readString(100);
    String p = EEPROM.readString(200);

    const char *ssid = "ESP32 WiFi Manager";
    const char *password = "admin";
    // const char *password = "12345678";

    Serial.println("Setting Access Point...");

    WiFi.softAP(ssid, password);

    IPAddress IP = WiFi.softAPIP();

    Serial.print("AP IP address: ");
    Serial.println(IP);

    server.on("/", handleRoot);

    server.onNotFound(handleNotFound);

    server.begin();

    Serial.println("HTTP server started");

    while (s.length() <= 0 && p.length() <= 0)
    {
        server.handleClient();
        delayMilliseconds(100);
    }

    return false;
}

/**
 * @brief Function checking WiFi creds in memory
 * 
 * @return true if not empty, else if empty 
 */
bool WiFiInput::checkWiFiCreds()
{
    Serial.println("Checking WiFi credentials");
    String s = EEPROM.readString(100);
    String p = EEPROM.readString(200);
#if DEBUG
    Serial.print("Found credentials: ");
    Serial.print(s);
    Serial.print("/");
    Serial.print(p);
    delayMilliseconds(5000);
#endif
    if (s.length() > 0 && p.length() > 0)
        return true;
    return false;
}

/**
 * @brief Wipe EEPROM
 * 
 */
void WiFiInput::wipeEEPROM()
{
    for (int i = 0; i < 400; i++)
    {
        EEPROM.writeByte(i, 0);
    }
    EEPROM.commit();
}
