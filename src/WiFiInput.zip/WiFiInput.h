#ifndef WIFIINPUT_H
#define WIFIINPUT_H

#include <Arduino.h>
#include <EEPROM.h>
#include <String>
#include <WebServer.h>

class WiFiInput
{
private:
    WebServer server(80);

    const char INDEX_HTML[] =
        "<!DOCTYPE HTML>"
        "<html>"
        "<head>"
        "<meta content=\"text/html; charset=ISO-8859-1\""
        " http-equiv=\"content-type\">"
        "<meta name = \"viewport\" content = \"width = device-width, initial-scale = 1.0, maximum-scale = 1.0, user-scalable=0\">"
        "<title>ESP8266 Web Form Demo</title>"
        "<style>"
        "\"body { background-color: #808080; font-family: Arial, Helvetica, Sans-Serif; Color: #000000; text-align:center;}\""
        "</style>"
        "</head>"
        "<body>"
        "<h3>Enter your WiFi credentials</h3>"
        "<form action=\"/\" method=\"post\">"
        "<p>"
        "<label>SSID:&nbsp;</label>"
        "<input maxlength=\"30\" name=\"ssid\"><br>"
        "<label>Key:&nbsp;&nbsp;&nbsp;&nbsp;</label><input maxlength=\"30\" name=\"password\"><br>"
        "<input type=\"submit\" value=\"Save\">"
        "</p>"
        "</form>"
        "</body>"
        "</html>";

public:
    WiFiInput() {}
    void begin();

    void handleNotFound();
    bool writeToMemory(String, String);
    void handleSubmit();
    void handleRoot();
    bool loadWiFiCredsForm();
    bool checkWiFiCreds();
    void wipeEEPROM();
}

#endif // WIFIINPUT_H
